"use client";
import { useEffect, useMemo, useState } from "react";
import { setAuthToken } from "../lib/api";
import { clearToken, getClaims, getToken } from "../lib/auth";

function fmtBR(d: Date) {
  const dd = String(d.getDate()).padStart(2,"0");
  const mm = String(d.getMonth()+1).padStart(2,"0");
  const yyyy = d.getFullYear();
  return `${dd}/${mm}/${yyyy}`;
}
function toISO(d: Date) {
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth()+1).padStart(2,"0");
  const dd = String(d.getDate()).padStart(2,"0");
  return `${yyyy}-${mm}-${dd}`;
}

export default function ScopePage() {
  const claims = useMemo(()=>getClaims(), []);
  const role = claims?.role;

  const [empresa, setEmpresa] = useState<number>(claims?.id_empresa ?? 1);
  const [filial, setFilial] = useState<number | "ALL">(claims?.id_filial ?? "ALL");
  const [dtIni, setDtIni] = useState<Date>(new Date(Date.now() - 14*24*3600*1000));
  const [dtFim, setDtFim] = useState<Date>(new Date());

  useEffect(() => {
    const t = getToken();
    if (!t) { window.location.href = "/"; return; }
    setAuthToken(t);
  }, []);

  const canChooseEmpresa = role === "MASTER";
  const canChooseFilial = role === "MASTER" || role === "OWNER";

  function logout() { clearToken(); window.location.href = "/"; }
  function go() {
    const q = new URLSearchParams();
    q.set("dt_ini", toISO(dtIni));
    q.set("dt_fim", toISO(dtFim));
    if (canChooseFilial && filial !== "ALL") q.set("id_filial", String(filial));
    window.location.href = `/dashboard?${q.toString()}`;
  }

  return (
    <div>
      <div className="nav">
        <div className="brand"><span>🧠</span><span>TorqMind</span><span className="pill">{role || "—"}</span></div>
        <button className="btn" onClick={logout}>Sair</button>
      </div>

      <div className="container">
        <div className="card" style={{ maxWidth: 720, margin: "28px auto" }}>
          <h1>Defina seu escopo</h1>
          <div className="muted">MASTER escolhe empresa/filial. OWNER escolhe filial (ou todas). MANAGER é fixo.</div>

          <div style={{ height: 16 }} />
          <div className="row row-2">
            <div className="card" style={{ padding: 14 }}>
              <h2>Empresa</h2>
              <div className="muted">Travado para OWNER/MANAGER.</div>
              <div style={{ height: 10 }} />
              <input className="input" disabled={!canChooseEmpresa} value={empresa} onChange={(e)=>setEmpresa(Number(e.target.value))}/>
            </div>

            <div className="card" style={{ padding: 14 }}>
              <h2>Filial</h2>
              <div className="muted">OWNER pode todas/uma. MANAGER travado.</div>
              <div style={{ height: 10 }} />
              <select className="input" disabled={!canChooseFilial} value={String(filial)} onChange={(e)=>{
                const v = e.target.value; setFilial(v==="ALL" ? "ALL" : Number(v));
              }}>
                <option value="ALL">Todas</option>
                <option value="1">Filial 1</option>
              </select>
            </div>
          </div>

          <div style={{ height: 16 }} />
          <div className="row row-2">
            <div className="card" style={{ padding: 14 }}>
              <h2>Data início</h2>
              <div className="muted">{fmtBR(dtIni)}</div>
              <div style={{ height: 10 }} />
              <input className="input" type="date" value={toISO(dtIni)} onChange={(e)=>setDtIni(new Date(e.target.value))}/>
            </div>
            <div className="card" style={{ padding: 14 }}>
              <h2>Data fim</h2>
              <div className="muted">{fmtBR(dtFim)}</div>
              <div style={{ height: 10 }} />
              <input className="input" type="date" value={toISO(dtFim)} onChange={(e)=>setDtFim(new Date(e.target.value))}/>
            </div>
          </div>

          <div style={{ height: 16 }} />
          <button className="btn" onClick={go}>Entrar no painel</button>
        </div>
      </div>
    </div>
  );
}
