import axios from "axios";
export const API_BASE = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:8000";
export const api = axios.create({ baseURL: API_BASE });
export function setAuthToken(token: string | null) {
  if (!token) { delete api.defaults.headers.common["Authorization"]; return; }
  api.defaults.headers.common["Authorization"] = `Bearer ${token}`;
}
function formatApiError(payload: any): string {
  if (!payload) return "Falha no login.";
  const d = payload.detail;

  if (typeof d === "string") return d;

  if (Array.isArray(d)) {
    const msgs = d
      .map((x) => x?.msg || x?.message || JSON.stringify(x))
      .filter(Boolean);
    return msgs.join(" | ") || "Falha no login.";
  }

  if (payload.message) return payload.message;

  return "Falha no login.";
}