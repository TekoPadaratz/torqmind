import { jwtDecode } from "jwt-decode";
export type Role = "MASTER" | "OWNER" | "MANAGER";
export type Claims = { sub: string; email: string; role: Role; id_empresa?: number|null; id_filial?: number|null; exp: number };
const KEY = "tm_token";
export function getToken(): string | null { if (typeof window === "undefined") return null; return window.localStorage.getItem(KEY); }
export function setToken(t: string) { window.localStorage.setItem(KEY, t); }
export function clearToken() { window.localStorage.removeItem(KEY); }
export function getClaims(): Claims | null {
  const token = getToken(); if (!token) return null;
  try { return jwtDecode(token) as Claims; } catch { return null; }
}
