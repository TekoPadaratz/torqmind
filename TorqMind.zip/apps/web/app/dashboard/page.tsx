"use client";
import { useEffect, useMemo, useState } from "react";
import { api, setAuthToken } from "../lib/api";
import { getClaims, getToken, clearToken } from "../lib/auth";
import { ResponsiveContainer, AreaChart, Area, CartesianGrid, XAxis, YAxis, Tooltip } from "recharts";

function moneyBR(v: number) { return v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" }); }
function labelDateKey(k: number) { const s = String(k); return `${s.slice(6,8)}/${s.slice(4,6)}`; }
function parseQuery() {
  const u = new URL(window.location.href);
  return { dt_ini: u.searchParams.get("dt_ini") || "", dt_fim: u.searchParams.get("dt_fim") || "", id_filial: u.searchParams.get("id_filial") };
}

export default function Dashboard() {
  const [kpis, setKpis] = useState<any>(null);
  const [series, setSeries] = useState<any[]>([]);
  const [insights, setInsights] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);

  const claims = useMemo(()=>getClaims(), []);
  const q = useMemo(()=>parseQuery(), []);

  useEffect(() => {
    const t = getToken();
    if (!t) { window.location.href="/"; return; }
    setAuthToken(t);

    (async () => {
      try {
        setError(null);
        const params: any = { dt_ini: q.dt_ini, dt_fim: q.dt_fim };
        if (q.id_filial) params.id_filial = Number(q.id_filial);

        const [rk, rs, ri] = await Promise.all([
          api.get("/dashboard/kpis", { params }),
          api.get("/dashboard/series", { params }),
          api.get("/dashboard/insights", { params }),
        ]);

        setKpis(rk.data);
        const pts = (rs.data.points || []).map((p:any)=>({ ...p, dia: labelDateKey(p.data_key) }));
        setSeries(pts);
        const ins = (ri.data.points || []).map((p:any)=>({ ...p, dia: labelDateKey(p.data_key) }));
        setInsights(ins);
      } catch (err:any) {
        setError(err?.response?.data?.detail || "Falha ao carregar dados");
      }
    })();
  }, []);

  const byDay = useMemo(() => {
    const m = new Map<number, { dia: string; faturamento: number; margem: number }>();
    for (const p of series) {
      const key = Number(p.data_key);
      const cur = m.get(key) || { dia: labelDateKey(key), faturamento: 0, margem: 0 };
      cur.faturamento += Number(p.faturamento || 0);
      cur.margem += Number(p.margem || 0);
      m.set(key, cur);
    }
    return Array.from(m.entries()).sort((a,b)=>a[0]-b[0]).map(([,v])=>v);
  }, [series]);

  const rankFiliais = useMemo(() => {
    const m = new Map<number, { id_filial: number; faturamento: number }>();
    for (const p of series) {
      const id = Number(p.id_filial);
      const cur = m.get(id) || { id_filial: id, faturamento: 0 };
      cur.faturamento += Number(p.faturamento || 0);
      m.set(id, cur);
    }
    return Array.from(m.values()).sort((a,b)=>b.faturamento - a.faturamento);
  }, [series]);

  function logout(){ clearToken(); window.location.href="/"; }

  return (
    <div>
      <div className="nav">
        <div className="brand">
          <span>🧠</span><span>TorqMind</span>
          <span className="pill">{claims?.role || "—"}</span>
          <span className="pill">Empresa {claims?.id_empresa ?? "—"}</span>
        </div>
        <div style={{ display:"flex", gap: 10 }}>
          <a className="btn" href="/scope">Escopo</a>
          <button className="btn" onClick={logout}>Sair</button>
        </div>
      </div>

      <div className="container">
        <h1>Painel Executivo</h1>
        <div className="muted">Consolidado (MART). Layout premium + sem gráfico poluído.</div>

        {error && <div className="card" style={{ marginTop: 16, borderColor:"rgba(251,113,133,0.4)" }}><div style={{ color:"#fb7185" }}>{error}</div></div>}

        <div style={{ height: 16 }} />
        <div className="row row-4">
          <div className="card kpi"><div className="label">Faturamento</div><div className="value">{kpis ? moneyBR(kpis.faturamento) : "—"}</div></div>
          <div className="card kpi"><div className="label">Margem</div><div className="value">{kpis ? moneyBR(kpis.margem) : "—"}</div></div>
          <div className="card kpi"><div className="label">Ticket médio</div><div className="value">{kpis ? moneyBR(kpis.ticket_medio) : "—"}</div></div>
          <div className="card kpi"><div className="label">Itens</div><div className="value">{kpis ? Number(kpis.itens).toLocaleString("pt-BR") : "—"}</div></div>
        </div>

        <div style={{ height: 16 }} />
        <div className="row row-2">
          <div className="card">
            <h2>Faturamento (consolidado)</h2>
            <div className="muted">Área consolidada. (Próximo: toggle para comparar mês anterior.)</div>
            <div style={{ height: 14 }} />
            <div style={{ width:"100%", height: 260 }}>
              <ResponsiveContainer>
                <AreaChart data={byDay}>
                  <CartesianGrid stroke="rgba(255,255,255,0.08)" vertical={false}/>
                  <XAxis dataKey="dia" tick={{ fill:"#9fb0d0", fontSize:12 }}/>
                  <YAxis tick={{ fill:"#9fb0d0", fontSize:12 }}/>
                  <Tooltip contentStyle={{ background:"#0f1a2e", border:"1px solid rgba(255,255,255,0.1)" }}/>
                  <Area type="monotone" dataKey="faturamento" stroke="#6ee7ff" fill="rgba(110,231,255,0.18)" strokeWidth={2}/>
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="card">
            <h2>Ranking de Filiais</h2>
            <div className="muted">Top 5 / Bottom 5 por faturamento no período.</div>
            <div style={{ height: 14 }} />
            <div className="row" style={{ gap: 12 }}>
              <div className="card" style={{ padding: 12 }}>
                <div className="muted">Top 5</div>
                {rankFiliais.slice(0,5).map((f)=>(
                  <div key={f.id_filial} style={{ display:"flex", justifyContent:"space-between", padding:"8px 0", borderBottom:"1px solid rgba(255,255,255,0.06)" }}>
                    <div>Filial {f.id_filial}</div><div style={{ fontWeight:700 }}>{moneyBR(f.faturamento)}</div>
                  </div>
                ))}
              </div>
              <div className="card" style={{ padding: 12 }}>
                <div className="muted">Bottom 5</div>
                {rankFiliais.slice(-5).map((f)=>(
                  <div key={f.id_filial} style={{ display:"flex", justifyContent:"space-between", padding:"8px 0", borderBottom:"1px solid rgba(255,255,255,0.06)" }}>
                    <div>Filial {f.id_filial}</div><div style={{ fontWeight:700 }}>{moneyBR(f.faturamento)}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div style={{ height: 16 }} />
        <div className="card">
          <h2>Jarvis (base consolidada)</h2>
          <div className="muted">Pronto para IA ler apenas `mart.insights_base_diaria`.</div>
          <div style={{ height: 10 }} />
          {insights.length === 0 ? (
            <div className="muted">Sem dados de insights no período.</div>
          ) : (
            <div className="row row-2">
              <div className="card" style={{ padding: 12 }}>
                <div className="muted">Último dia</div>
                <div style={{ fontSize: 20, fontWeight: 700 }}>{moneyBR(insights[insights.length-1].faturamento_dia)}</div>
                <div className="muted">Comparativo M/M: {moneyBR(insights[insights.length-1].comparativo_mes_anterior)}</div>
              </div>
              <div className="card" style={{ padding: 12 }}>
                <div className="muted">Faturamento mês (acum.)</div>
                <div style={{ fontSize: 20, fontWeight: 700 }}>{moneyBR(insights[insights.length-1].faturamento_mes_acum)}</div>
                <div className="muted">Próximo: alertas automáticos e score operacional.</div>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
