import argparse, json, gzip, io
import requests

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--api", required=True, help="Base da API, ex: http://localhost:8000")
    ap.add_argument("--dataset", default="movprodutos")
    args = ap.parse_args()

    rows = [{"id_empresa": 1, "id_filial": 1, "id_db": 1, "id_movprodutos": 123, "datarepl": "2025-01-01T00:00:00Z"}]
    ndjson = "\n".join(json.dumps(r, ensure_ascii=False) for r in rows).encode("utf-8")

    buf = io.BytesIO()
    with gzip.GzipFile(fileobj=buf, mode="wb") as gz:
        gz.write(ndjson)

    headers = {"Content-Type": "application/x-ndjson", "Content-Encoding": "gzip"}
    url = f"{args.api.rstrip('/')}/ingest/{args.dataset}"
    r = requests.post(url, data=buf.getvalue(), headers=headers, timeout=60)
    print(r.status_code, r.text[:500])

if __name__ == "__main__":
    main()
