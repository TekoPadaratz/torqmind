from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    pg_host: str = "postgres"
    pg_port: int = 5432
    pg_database: str = "torqmind"
    pg_user: str = "postgres"
    pg_password: str = "postgres"

    api_jwt_secret: str = "CHANGE_ME_SUPER_SECRET"
    api_jwt_issuer: str = "torqmind-api"
    api_access_token_minutes: int = 60

    class Config:
        env_file = ".env"
        extra = "ignore"

settings = Settings()
