from __future__ import annotations
import contextlib
from typing import Iterator, Optional
import psycopg
from psycopg.rows import dict_row
from app.config import settings

def _conn_str() -> str:
    return (
        f"host={settings.pg_host} port={settings.pg_port} dbname={settings.pg_database} "
        f"user={settings.pg_user} password={settings.pg_password}"
    )

@contextlib.contextmanager
def get_conn(role: Optional[str]=None, tenant_id: Optional[int]=None, branch_id: Optional[int]=None) -> Iterator[psycopg.Connection]:
    conn = psycopg.connect(_conn_str(), row_factory=dict_row)
    try:
        if role is not None:
            conn.execute("SET LOCAL app.role = %s", (role,))
        if tenant_id is not None:
            conn.execute("SET LOCAL app.tenant_id = %s", (str(tenant_id),))
        if branch_id is not None:
            conn.execute("SET LOCAL app.branch_id = %s", (str(branch_id),))
        yield conn
    finally:
        conn.close()
