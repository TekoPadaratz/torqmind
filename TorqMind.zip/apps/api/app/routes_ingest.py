from __future__ import annotations
from fastapi import APIRouter, Request, HTTPException
import gzip, json

router = APIRouter(prefix="/ingest", tags=["ingest"])

@router.post("/{dataset}")
async def ingest(dataset: str, request: Request):
    body = await request.body()
    enc = (request.headers.get("content-encoding","") or "").lower()
    if enc == "gzip":
        try:
            body = gzip.decompress(body)
        except Exception:
            raise HTTPException(status_code=400, detail="Invalid gzip")

    lines = body.splitlines()
    # MVP: validate only first few lines
    preview = 0
    for ln in lines[:10]:
        if not ln.strip():
            continue
        json.loads(ln)
        preview += 1

    return {"ok": True, "dataset": dataset, "preview_lines": preview, "total_lines": len(lines)}
