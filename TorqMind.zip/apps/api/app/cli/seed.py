from __future__ import annotations
from app.db import get_conn
from app.security import hash_password
import os

def main():
    master_email = "master@torqmind.com"
    owner_email = "owner@empresa1.com"
    manager_email = "gerente@filial1.com"
    password = os.getenv("SEED_PASSWORD", "TorqMind@123")

    if len(password.encode("utf-8")) > 72:
        raise RuntimeError(
            f"SEED_PASSWORD tem {len(password.encode('utf-8'))} bytes. "
            "bcrypt suporta no máximo 72 bytes. Ajuste o SEED_PASSWORD."
        )    

    with get_conn() as conn:
        conn.execute("INSERT INTO auth.users (email, password_hash) VALUES (%s,%s) ON CONFLICT (email) DO NOTHING",
                     (master_email, hash_password(password)))
        conn.execute("INSERT INTO auth.users (email, password_hash) VALUES (%s,%s) ON CONFLICT (email) DO NOTHING",
                     (owner_email, hash_password(password)))
        conn.execute("INSERT INTO auth.users (email, password_hash) VALUES (%s,%s) ON CONFLICT (email) DO NOTHING",
                     (manager_email, hash_password(password)))

        master_id = conn.execute("SELECT id FROM auth.users WHERE email=%s", (master_email,)).fetchone()["id"]
        owner_id  = conn.execute("SELECT id FROM auth.users WHERE email=%s", (owner_email,)).fetchone()["id"]
        manager_id= conn.execute("SELECT id FROM auth.users WHERE email=%s", (manager_email,)).fetchone()["id"]

        conn.execute("INSERT INTO auth.user_tenants (user_id, role, id_empresa, id_filial) VALUES (%s,'MASTER',NULL,NULL) ON CONFLICT DO NOTHING", (master_id,))
        conn.execute("INSERT INTO auth.user_tenants (user_id, role, id_empresa, id_filial) VALUES (%s,'OWNER',1,NULL) ON CONFLICT DO NOTHING", (owner_id,))
        conn.execute("INSERT INTO auth.user_tenants (user_id, role, id_empresa, id_filial) VALUES (%s,'MANAGER',1,1) ON CONFLICT DO NOTHING", (manager_id,))
        conn.commit()

    print("Seed OK.")
    print("MASTER :", master_email, "/", password)
    print("OWNER  :", owner_email, "/", password)
    print("MANAGER:", manager_email, "/", password)

if __name__ == "__main__":
    main()
