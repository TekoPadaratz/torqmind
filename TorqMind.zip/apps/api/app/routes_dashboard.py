from __future__ import annotations
from datetime import date
from typing import Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException
from app.deps import get_current_claims
from app.schemas import DashboardKpisResponse, DashboardSeriesResponse, DashboardSeriesPoint, InsightsResponse, InsightsPoint
from app import repos_mart

router = APIRouter(prefix="/dashboard", tags=["dashboard"])

def _claims_scope(claims: Dict[str, Any]) -> tuple[str, Optional[int], Optional[int]]:
    role = claims.get("role")
    id_empresa = claims.get("id_empresa")
    id_filial = claims.get("id_filial")
    if role not in ("MASTER","OWNER","MANAGER"):
        raise HTTPException(status_code=401, detail="Invalid role")
    return role, id_empresa, id_filial

@router.get("/kpis", response_model=DashboardKpisResponse)
def kpis(dt_ini: date, dt_fim: date, id_filial: Optional[int] = None, claims: Dict[str, Any] = Depends(get_current_claims)):
    role, tenant, branch = _claims_scope(claims)
    if tenant is None and role != "MASTER":
        raise HTTPException(status_code=400, detail="Token missing tenant")
    if role == "MANAGER":
        id_filial = branch
    data = repos_mart.dashboard_kpis(role, int(tenant or 1), id_filial, dt_ini, dt_fim)
    return DashboardKpisResponse(
        faturamento=float(data["faturamento"]),
        margem=float(data["margem"]),
        ticket_medio=float(data["ticket_medio"]),
        itens=int(data["itens"]),
    )

@router.get("/series", response_model=DashboardSeriesResponse)
def series(dt_ini: date, dt_fim: date, id_filial: Optional[int] = None, claims: Dict[str, Any] = Depends(get_current_claims)):
    role, tenant, branch = _claims_scope(claims)
    if role == "MANAGER":
        id_filial = branch
    rows = repos_mart.dashboard_series(role, int(tenant or 1), id_filial, dt_ini, dt_fim)
    pts = [DashboardSeriesPoint(
        data_key=int(r["data_key"]),
        id_filial=int(r["id_filial"]),
        faturamento=float(r["faturamento"]),
        margem=float(r["margem"]),
    ) for r in rows]
    return DashboardSeriesResponse(points=pts)

@router.get("/insights", response_model=InsightsResponse)
def insights(dt_ini: date, dt_fim: date, id_filial: Optional[int] = None, claims: Dict[str, Any] = Depends(get_current_claims)):
    role, tenant, branch = _claims_scope(claims)
    if role == "MANAGER":
        id_filial = branch
    rows = repos_mart.insights_base(role, int(tenant or 1), id_filial, dt_ini, dt_fim)
    pts = [InsightsPoint(
        data_key=int(r["data_key"]),
        id_filial=int(r["id_filial"]),
        faturamento_dia=float(r["faturamento_dia"]),
        faturamento_mes_acum=float(r["faturamento_mes_acum"]),
        comparativo_mes_anterior=float(r["comparativo_mes_anterior"]),
    ) for r in rows]
    return InsightsResponse(points=pts)
