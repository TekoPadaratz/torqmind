CREATE SCHEMA IF NOT EXISTS mart;

CREATE TABLE IF NOT EXISTS mart.agg_vendas_diaria (
  id_empresa         integer NOT NULL,
  id_filial          integer NOT NULL,
  data_key           integer NOT NULL,
  faturamento        numeric(18,2) NOT NULL DEFAULT 0,
  quantidade_itens   integer NOT NULL DEFAULT 0,
  margem             numeric(18,2) NOT NULL DEFAULT 0,
  ticket_medio       numeric(18,2) NOT NULL DEFAULT 0,
  updated_at         timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id_empresa, id_filial, data_key)
);

CREATE TABLE IF NOT EXISTS mart.insights_base_diaria (
  id_empresa               integer NOT NULL,
  id_filial                integer NOT NULL,
  data_key                 integer NOT NULL,
  faturamento_dia          numeric(18,2) NOT NULL DEFAULT 0,
  faturamento_mes_acum     numeric(18,2) NOT NULL DEFAULT 0,
  comparativo_mes_anterior numeric(18,2) NOT NULL DEFAULT 0,
  top_vendedor_key         text NULL,
  top_vendedor_valor       numeric(18,2) NULL,
  inadimplencia_valor      numeric(18,2) NULL,
  inadimplencia_pct        numeric(9,4) NULL,
  cliente_em_risco_key     text NULL,
  margem_media_pct         numeric(9,4) NULL,
  giro_estoque             numeric(18,2) NULL,
  updated_at               timestamptz NOT NULL DEFAULT now(),
  batch_info               jsonb NOT NULL DEFAULT '{}'::jsonb,
  PRIMARY KEY (id_empresa, id_filial, data_key)
);

INSERT INTO auth.filiais (id_empresa, id_filial, nome)
VALUES (1,1,'Filial 1')
ON CONFLICT DO NOTHING;

DO $$
DECLARE d date := current_date - interval '14 days';
BEGIN
  FOR i IN 0..14 LOOP
    INSERT INTO mart.agg_vendas_diaria (id_empresa,id_filial,data_key,faturamento,quantidade_itens,margem,ticket_medio)
    VALUES (1,1,to_char((d+i)::date,'YYYYMMDD')::int, (random()*50000+20000)::numeric(18,2), (random()*1200+300)::int, (random()*6000+1500)::numeric(18,2), (random()*80+20)::numeric(18,2))
    ON CONFLICT DO NOTHING;

    INSERT INTO mart.insights_base_diaria (id_empresa,id_filial,data_key,faturamento_dia,faturamento_mes_acum,comparativo_mes_anterior,top_vendedor_key,top_vendedor_valor,margem_media_pct,giro_estoque,batch_info)
    VALUES (1,1,to_char((d+i)::date,'YYYYMMDD')::int, (random()*50000+20000)::numeric(18,2), (random()*400000+100000)::numeric(18,2), (random()*20000-10000)::numeric(18,2),
      'VEND_1', (random()*5000+1000)::numeric(18,2), (random()*0.2+0.08)::numeric(9,4), (random()*40+10)::numeric(18,2),
      jsonb_build_object('demo',true))
    ON CONFLICT DO NOTHING;
  END LOOP;
END $$;
