# TorqMind Monorepo (Web + API + Agent)

Este repositório contém:
- `apps/api`  : FastAPI (Auth + Multi-tenant + endpoints de dados do MART)
- `apps/web`  : Next.js (UI premium) consumindo a API
- `apps/agent`: Agente ETL (rodando no cliente) que envia batches para a API
- `sql/migrations`: migrações SQL (auth + helpers RLS + demo mart)

## Rodar local (Docker)
1) Copie `.env.example` para `.env`.
2) Suba:
```bash
docker compose up --build
```

- Web: http://localhost:3000
- API: http://localhost:8000/docs
- Postgres: localhost:5432

## Usuários
Depois de subir, rode a seed:
```bash
docker compose exec api python -m app.cli.seed
```

Cria:
- MASTER: master@torqmind.local / TorqMind@123
- OWNER : owner@empresa1.local / TorqMind@123  (empresa 1)
- MANAGER: gerente@filial1.local / TorqMind@123 (empresa 1, filial 1)

> Em produção, o MASTER escolhe empresa/filial antes de ver dados (tela /scope).
